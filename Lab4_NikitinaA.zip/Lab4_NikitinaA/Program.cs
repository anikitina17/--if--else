﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_NikitinaA
{
    internal class Program
    {
        static void Main(string[] args)

        {
            Console.OutputEncoding = System.Text.Encoding.GetEncoding(1251);
            Console.WriteLine("Початкове значення діапазону:");
            int low = int.Parse(Console.ReadLine());
            Console.WriteLine("Кінцеве значення діапазону");
            int high = int.Parse(Console.ReadLine());

            // змінні для першого виразу
            Console.WriteLine("Введіть a(>=0): ");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Введіть x(>=0): ");
            int x = int.Parse(Console.ReadLine());
            Console.WriteLine("Введіть t(>=0): ");
            int t = int.Parse(Console.ReadLine());

            // змінні для другого виразу
            Console.WriteLine("Введіть b: ");
            double b = double.Parse(Console.ReadLine());

            // змінні для третього виразу
            Console.WriteLine("Введіть c: ");
            float c = float.Parse(Console.ReadLine());

            // a,x,t -лише додатні
            if (a <= 0 || x <= 0 || t <= 0)
            {
                Console.WriteLine("Помилка! Введіть лише додатні числа.");
                return;
            }


            int i = -a * x * t + (a + x * t);
            double j = a + x / 2;
            double k = c * a + x / 4;



            Console.WriteLine("Результат обчислень");

            Console.WriteLine($" 1) = {i} ");
            Console.WriteLine($" 2) = {j} ");
            Console.WriteLine($" 3) = {k}");

            if (i >= low && i <= high) 
            Console.WriteLine("Результат входить у діапазон значень!");
            else
                Console.WriteLine("Результат не входить у діапазон значень!");

            if (j >= low && j <= high) 
            Console.WriteLine("Результат входить у діапазон значень!");
            else
                Console.WriteLine("Результат не входить у діапазон значень!");

            if (k >= low && k <= high) 
            Console.WriteLine("Результат входить у діапазон значень!");
            else
                Console.WriteLine("Результат не входить у діапазон значень!");
        
        }
    }
}
